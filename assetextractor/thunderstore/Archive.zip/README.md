# Asset Extractor 
whgat it says on the tin !!!!!!!!!!!!!!!!! extract game/mod assets from contentpacks by pressing f5 ...,.,,. exports both as png files and lua table datasets (meant for use with starstorm2.wiki.gg or riskofrain2.wiki.gg ( !!!!!!!!!

once finished you'll be able to find them in the mod's folder under a "wiki" folder (will also be logged so like ,.,.. )

also will eat up a little bit of ram while exporting depending on how many mods you have ,..,., should clear when loading a new unity scene like character select screen though !!

currently supported ,..,.,
- items and equipments
- survivors
- skills
- skins
- challenges (only lua datasheet export)
- bodies (monsters)

also logs attack procs !!(configurable.,.,,.

example of exported mod contentpack.,.,

![paladin contentpack screenshot](https://files.catbox.moe/shvkft.png)

example of wiki folder ,.,,.

![wiki folder screenshot](https://files.catbox.moe/i82trm.png)

## todo .,,
- lore probably 
- maybeeee interactables ? not sure how possible .,.,.
- stages
- difficulties
- expansion icons 
- artifacts
- automatically check for file conflicts instead of overwriting 
- configurable formatting 

## credits !!!!!!!!!!!!!!!

ss2 team - original item extraction code !!

hifu - hi hifu !!!!!!!!!!!!!

anartoast - was in the mod icon !!






![](https://files.catbox.moe/yr7vmg.gif)
