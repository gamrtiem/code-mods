# ButterscotchandRosesBaseMod
note !! this is mostly a modpack base mod for myself !!!!! just uploading to thunderstore so im able to share via modpack codes ,,.,. so some things arent done very well ,..,. be warned !!!!!!!!!!!!!! also have not tested this in multiplayer very much so .,.,,. ,., .,,.

everything is configurable to some degree too ,.,,. so if you dont like an edit !! just disable it you freak !!!

### basegame edits ,.,,.
<details>
<summary> ui edits !!  </summary>

- (disabled by default since fairlys buggy ,.,.) customize button colors .,.,.
- shrink money to be how it used to pre SOTV (i miss you ,,,..,,..

![](https://files.catbox.moe/4cse35.png)

</details>

<details>
<summary> halcyonite shrines  !!  </summary>

- speed up by 2x (configurable) with a time penalty ,..,,.
  - i have been informed bys canthi that this is actually just like [slendykrays faster charge](https://thunderstore.io/package/Slendykray/FasterCharge/) so um ,..,.,  oops !!
- only speed up if theres less than x amount of players (configurable( ,.,,.,.
- turn green portal into blue once the teleporter event is complete !!!! (im sorry i dont want to go on colossus' wild ride !!!

</details>

<details>
<summary> drifter !!!  !!  </summary>

- set scrapcube deployable limit ,..,

</details>

<details>
<summary> malachites !!!  !!  </summary>

- haves them spawn urchins every 12 seconds !! wisterawolf askeds for this one but merging into here so its on thunderstores ,.,..,

</details>

<details>
<summary> drone visibility !!!  !!  </summary>

- older ands or more janky version of [drone repair beacon](https://thunderstore.io/package/icebro/DroneRepairBeacon/) !!!! but aesthetics differents ,,..,.,, addeds by request of kismet o ndiscord !!!
- code is a bit silly so money will also be visible for however long the indicator is but donts worry about it <333

![](https://files.catbox.moe/cn0sil.png)

![](https://files.catbox.moe/ex0e5h.png)
</details>

<details>
<summary> ping recolors !!!  !!  </summary>

- recolor pings !!! colors in screenshots are different from default config; just all set to regular ping ,..,

![](https://files.catbox.moe/okvzsw.png)

![](https://files.catbox.moe/jem5kv.png)

![](https://files.catbox.moe/kauzte.png)


</details>

### mod edits ,..,.,
<details>
<summary> cooler eclipse edits!!  </summary>

- [mod link ,..,](https://thunderstore.io/package/Nuxlar/CoolerEclipse/)
 - adds config chance to eclipses rather than just 50-50 .,.,
 - adds a 'pink' variant of eclipse ,.,,,
 - adds a stage blacklist and whitelist (unsure if whitelist functions correctl y.,,.,.,

![](https://files.catbox.moe/4b7ov1.png)

</details>

<details>
<summary> golden coast plus revived edits !!  </summary>

- [mod link ,..,](https://thunderstore.io/package/TechDebtCollector/GoldenCoastPlus/)
 - skip buff given when you beat (i didnt like sorr y,..,.,,.,.

</details>

<details>
<summary> starstorm !!  </summary>

- [mod link ,..,](https://thunderstore.io/package/TeamMoonstorm/Starstorm2/)
 - (might break if beta isnt enabled ( give icetool a chance to freeze (eg. artificer wall( enemies on hit !!! kinds of broken tbh because of the execute but its okay <33 ,.,.,.,

</details>

<details>
<summary> inferno !!  </summary>

- [mod link ,..,](https://thunderstore.io/package/prodzpod/Inferno/)
 - remove beetles not being able to be stunned !!! we hate beetle s !!!!!!!!!!!!!!

</details>

<details>
<summary> allynames !!  </summary>

- [mod link ,.,.](https://thunderstore.io/c/riskofrain2/p/SwagWizards/AllyNames/)
 - add custom body name config !!!! add any body names you want for thems to be renamed .,,.,. comes with oddbreads pr for allyname's alloyed collective pr by them !!! go say thank you !!!!!

![](https://files.catbox.moe/g5hbx6.png)
</details>

### items ,.,.
|![carving kit](https://raw.githubusercontent.com/gamrtiem/code-mods/refs/heads/main/butterscotchnroses/assetbundle/carvingkit.png) | **Carving Kit** | After interacting with a ``Shrine of the Woods``, gain a piece of``bark`` that drops after standing still for ``2`` seconds, healing for ``6%`` ``(+4% per stack)`` of your health every second to all allies within ``7m`` ``(+4m per stack)``. Guarantee a ``Shrine of the Woods`` spawn.
|:-|-|------|

![](https://files.catbox.moe/u8kke4.png)

special ultra thanks you to acanthi for modeling and makings carving kit icon real !!!!!!!!!!!!!!!!!!!!!!everyones say we love you canthi ,.,.
