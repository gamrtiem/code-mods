## 0.1.2
- carving kit model and icons !!!!!!!! thanks you canthi :pleading: .,,.. ,,..,. ,., .,.,., ., 
- hopefullys networked carving kit special material for free shrine and little shrineling !!!!
- updated mod icon !!!!!!!!
- added old drone visibility thing !!!!! little icon above dead drones .,.,.,,. like other drone visibility mod but old and worse code .,.,,. style thing !! 
- added ping recolors !!!!color your pings !!!!!!!!!!!!!!!!!! (wolfoqol friendly ping not supporteds yet <//3 ,.., 

## 0.1.1
- added ally name support !!!!!!! nows able to add any body name ,.,..,.,., sorrys oddbread on github took ac names from your pr to ally names ,..,,..,.,,..,., .,. 
- fixed carving kit disable not owrkings i think !! and added custom material for free shrine of the woods !!!!!!
- networked green portal to blue portal halcyon shrine edit !!!! portal will now appear correctlys for clients ,.., 
- fixed inferno changes doing !! nothing i think ,.., 

## 0.1.0
- releas e!!!
