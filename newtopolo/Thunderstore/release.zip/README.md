# NewtoPolo

credit to the [original mod for the code](https://thunderstore.io/package/Cuppa/NewtoPolo/) (it really is just a recompiled version) !!!!!!!!!!!!!!!!!!

play marco polo with either the newt altar or ethereal sapling by typing "newto" or "saplo" respectively !!!!!!!!!!!!!!!!!
issues might persist from original mod ,..,,..
