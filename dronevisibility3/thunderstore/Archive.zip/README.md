# Drone Repair Beacon
adds a little beacon above killed drones and makes them scream in agony !! configurable ,.., 
