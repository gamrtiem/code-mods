# Heart of the Collective

adds a special guaranteed boss item dropped by breaking a certain solus's heart !!!!!!!!!!! like ..,.,,, pretty configurable !!!!!!

|![null heart ingame icon](https://files.catbox.moe/rixsj7.png) | **Null Heart** | Prevent `Solus Distributors`, `Solus Extractors`, and `Solus Invalidators` from spawning and gain a `25%` chance to deal `50%` TOTAL damage against solus enemies.
|:-|-|------|

mod commissioned (and mod icon/item lore) by imDolos !!!!!!

![null heart on hit in game](https://files.catbox.moe/42kp1j.gif)



<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

![awesome epic](https://files.catbox.moe/2ywe6h.gif)

